<?php
$tmx = [
'toolkit/toolkit/updates/elevation.ftl:elevation-update-wizard.title' => 'Software Update',
];